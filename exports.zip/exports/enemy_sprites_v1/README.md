# Enemy base graphics extraction v1

2026-10-21. Phase 1, bounded read-only static analysis. No emulator, ROM edits,
unrestricted Ghidra analysis, NPC/Gimmick extraction, or commits.

## Results

Of 182 named enemy records, **127 have verified direct base-frame mappings**:
254 transparent native-resolution PNGs and 254 optional nearest-neighbor 4x PNGs.
**55 records remain explicitly unresolved** (41 unsupported dimension selectors;
14 noncanonical layout arrays). This is 69.8% record coverage, not complete
animation coverage or 127 unique species. Repeated/shared assets remain associated
with each record. No unsupported enemy receives a guessed sprite or palette.

Local assets and CSVs: `assets/`. `enemies.csv` catalogs all 182 IDs; `frames.csv`
contains per-frame offsets, dimensions, palette provenance, format, confidence,
hashes and limitations. `unresolved.csv` lists every rejected ID/name and reason.
No pose names, timing, attack overlays, status palettes or runtime behavior are
inferred. Artwork outside the two old fixtures was not individually visually
validated; verification concerns record-to-resource linkage and the decoder.

Inputs: original Japanese SHA-256
`0d44380a3eed065b6ca0992d80a248ab001b978e925f7687d5dfcf1ae70e5c12`;
English baseline SHA-256
`8d27aac43d50eab17d7ba8b4183cb7c70dbd74194d11b3f8c011c61d13b5adde`.
Every accepted record's graphics selector, pointers, dimension entry, palette,
layout and consumed compressed streams are byte-identical at the same offsets
in both inputs. Thus these graphics are original Japanese assets, not relocated
English graphics. Names come from toolkit `ta_enemies_eng.txt`, NAMES section.
The cumulative Detector ROM is protected, not used as extraction input.

## Address/evidence ledger

Addresses in the first column are **file offsets** in both baselines; add
`0x08000000` for ROM bus addresses. Full bounded Thumb excerpts with instruction
bytes, source intervals and JP/English equality are in `static_windows.json`.
Source symbols refer to `tools/extract/enemy_sprites_v1/extract_enemy_sprites.py`
unless another source is named. Confidence is **Confirmed static** within the
accepted direct-record format, not a claim that every enemy uses this path.

| File offset/range | Symbol / purpose | Supporting evidence | Confidence |
|---|---|---|---|
| `0x00634F50..0x00638558` exclusive | `TABLE/STRIDE/COUNT`: 182 records, stride 0x4C | toolkit `inserter/text.cpp:EnemyInfoAddress`; 182 contiguous NAMES entries; prior bestiary | Confirmed |
| record `+0x2F` | `decode_record`: direct dimension selector | `0x0004C674..0x0004C684`: byte read, multiply by four, two halfword dimensions | Confirmed |
| `0x00486548..0x00486560` exclusive | `DIMS`: **six** width/height pairs in tiles | `0x0004C610..0x0004C61A` copies two sets of three words (24 bytes) from literal bus `0x08486548` to stack | Confirmed |
| record `+0x34` (4 bytes) | raw 16-color palette pointer | `0x0004C6F4..0x0004C708`: DMA eight words to OBJ palette; BG fallback `0x0004C7D0..0x0004C7EC` | Confirmed |
| record `+0x38/+0x3C` | base frame pointer slots 0/1 | `0x0004C70A..0x0004C718`: target byte +0x29 selects pointer; XOR 1 at `0x0004C034..0x0004C03E`, `0x0004C2FE..0x0004C308`; old fixtures | Confirmed |
| record `+0x40` (4 bytes) | layout reference, acceptance gate | prior palace investigation and fixtures; every accepted halfword equals `0x6200+32*y+x`; no flips or extra palette banks | Confirmed for accepted rectangles |
| `0x00040014..0x00040064` | compression dispatcher | header high nibble 0x10 -> BIOS wrapper bus 0x080942F0; 0x30 -> 0x080942FC | Confirmed |
| `0x0003FFA0..0x0004000A` | compact tile row upload | width*32-byte source rows, 1024-byte destination pitch; matches old renderer and accepted layouts | Confirmed |
| `0x0004C83C..0x0004C8A0` | bounded prefix of alternative pipeline | reads record +0x2D nibbles; incomplete trace, no special selector interpretation implemented | Candidate for follow-up only |

The six verified dimension pairs are (5,5), (7,7), (10,5), (10,5),
(12,5), (10,5). **Do not extend the table into following ROM bytes** or mask
large selectors to force a fit. Fourteen otherwise in-range records fail the
canonical-layout gate; their composition/dimension mapping remains unresolved.
For example Pothead 17, Cyborg 53, Invisidude 54 and several bosses are excluded.
The CSV enumerates all 55 cases without assigning causes beyond the failed gate.

## Decoding and toolkit comparison

Reuse the strict bounded `extract_field_maps.decompress` (0x10 LZ77 / 0x30 RLE)
and PNG writer, plus `extract_palace_enemy_sprites.render/enlarge`. All 254
accepted streams actually use **0x10 LZ77**; RLE is helper-supported and tested
synthetically, with no claim of a verified RLE enemy asset. Exact decompressed
size must equal width*height*32, and pointers/reads must remain inside the ROM.
Both frames must pass before either is exported. No raw-header fallback.

Inspected toolkit routines: `inserter/images.cpp:LoadPaletteAt/CompressTileset`,
`tiles.cpp:Palette::Load` and 4bpp tile decoding (low nibble first),
`lz77.cpp:decompress_gba_lz77`, `rle.cpp:decompress_gba_rl`.
LZ token order/backreferences agree with the strict Python decoder. The toolkit
RLE routine has `(input[3] < 16)` rather than a shift in its size expression;
the extractor does not copy that expression. No toolkit files were modified.
Palette channels expand with `(v<<3)|(v>>2)`, index zero alpha 0, others 255;
RGB under transparency is preserved for exact legacy PNG regression.

## Reproduction and tests

From the workspace root, supplying a fresh output path:

```powershell
python -B tools/extract/enemy_sprites_v1/extract_enemy_sprites.py --output NEW_VERSION_DIRECTORY --previews
python -B tools/extract/enemy_sprites_v1/test_enemy_sprites.py
python -B -m unittest discover -s tests -p test_extract_field_maps.py -v
```

Seven enemy checks and nine existing field-map checks pass. The two old enemies
match all **eight prior PNG files byte for byte** (native and 4x) and all four
decompressed-frame hashes. Native exports are checked for dimensions, PNG chunk
CRCs, RGBA scanline sizes, binary alpha and presence of transparency. Tests also
reject malformed streams/pointers, unsupported selectors/layouts and existing
output directories; overlapping LZ and RLE tokens have synthetic checks.
`verification_v1.json` contains captured test results, coverage consistency and
protected-artifact hashes audit results. These are static tests, not runtime tests.

## Preservation

All session writes are in the new `tools/extract/enemy_sprites_v1/` and this
versioned export directory. Existing ROMs, saves, savestates, PNGs, CSVs, scripts
and reports were never opened for writing. `protected_baseline_v1.json` records
3,031 existing relevant artifacts, including the cumulative Detector ROM;
verification rehashes each. Installed Ghidra libraries/classes are excluded.
The broader inventories did not complete: one encountered an inaccessible long
Java-class path, and the other was stopped. The scoped baseline completed after initial exports.
Consequently this is a final preservation recheck plus restricted write-path
evidence, not a completed pre-extraction hash snapshot. That limitation is explicit.
Asset output directories contain a local ignore file; copyrighted PNGs remain
local. No assets or other files were committed.
