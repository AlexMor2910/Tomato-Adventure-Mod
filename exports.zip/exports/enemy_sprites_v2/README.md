# Enemy sprite extraction v2

2026-10-21. Read-only Phase 1 analysis, restricted to the **55 v1 unresolved
records**. The other 127 records use the frozen v1 decoder for regression only.
No ROM changes, emulator operation, unrestricted Ghidra work, commits, or
NPC/Gimmick extraction.

## Canonical results

Use **`final/`**, not the exploratory `assets/` or `verified/` runs. Those new v2
intermediate directories are retained without overwriting them; their catalogs
are superseded by `final/`. All pre-existing v1 directories are untouched.

| Coverage | Records | Native frames | 4x previews |
|---|---:|---:|---:|
| Preserved v1 mappings | 127 | 254 | 254 |
| Newly verified v2 mappings | **23** | **60** | **60** |
| Verified total | **150 / 182 (82.4%)** | **314** | **314** |
| Remaining unresolved | **32** | 0 exported | 0 exported |

The 23 additions comprise **all 14 formerly noncanonical direct layouts** and
**nine multipart owners**. The 32 remaining records are **25 with null graphics
references**, **six whose tilemap and OAM compositions disagree**, and **Chekkit
8C, whose base frame 2 fails strict RLE decoding**. Full ID/name lists and precise
reasons are in `final/enemies.csv` and `final/unresolved.csv`. No partial enemy
cycle or candidate image is exported for an unresolved record.

`final/frames.csv` records every frame's enemy ID/name, dimensions, record and
pointer-field offsets, compressed source ranges, palette provenance, layout,
format, state selection, confidence and hashes. Multipart source details include
the independent streams and their VRAM upload rectangles. `final/evidence.json`
contains the 23 accepted mappings with exact source-span hashes, Japanese/English
comparisons and independent OAM proof. `bounded_evidence_final.json` inventories
**all 55** investigated records and includes bounded native instruction excerpts.

Frames are numbered pointer/cycle indices, not inferred attack/idle pose names.
Exports cover **palette-table entry 0 and per-part actor flag state 0**, with the
base cycle only. This is a supported static render configuration, not a claim
that every encounter starts in that configuration. In particular the initializer
has Death Lilby-specific child-state flags at bus `08048348..08048364`; other
state combinations, palette changes, script effects, secondary overlays and
runtime reachability remain unproved and are not exported. Null-pointer child
records are not assigned their neighbor's artwork.

## Verified format findings

Addresses below are **ROM bus addresses**, unchanged between the verified JP and
English sources. File offset = bus minus `08000000`. Individual asset offsets,
source hashes and decoding results are in the CSV/JSON rather than guessed from
adjacency. Symbols refer to `tools/extract/enemy_sprites_v2/extract_enemy_sprites.py`.

| Address / field | Purpose and source symbol | Evidence | Confidence |
|---|---|---|---|
| Enemy table `08634F50..08638558` exclusive, stride `4C` | Existing ID/record mapping | v1 metadata and toolkit `EnemyInfoAddress`; no new investigation of the 127 accepted records | Confirmed, inherited |
| `08486548..08486560` exclusive, record `+2F` in 0..5 | **Upload** dimensions, not necessarily displayed canvas; `new_record/upload` | `0804C610..61A`, `0804C674..684`, `0804C720..73C`; compact source rows become 32-tile VRAM rows | Confirmed |
| Direct record `+40`, `+44`, `+48` | BG tilemap, OBJ descriptor tables, animation table | actor setup `0804BE5A..BE9A`; default pointers `0804C0D6..C0EE`; draw helper `08040632..4071E` | Confirmed for exported frames |
| OAM descriptor header and entries: per-record `oam_proof` | Actual canvas and tile placement; `object_render` | Counts plus six-byte hardware OBJ entries (attributes 0/1/2), dispatched by `080406B0..406D4`; native raw OBJ copy/coordinate adjustment `080402A8..4035E` | Confirmed for accepted non-affine 4bpp lists |
| Multipart record `+2E` | Canvas width = high nibble, height = low nibble, in tiles | initializer `080481BA..48220`; repeated loader extraction `0804C8A0..8AC`; equality to independent OAM bounds | Confirmed for accepted owners |
| Multipart record `+34` | Palette-set pointer table; entry 0 points to 128 raw bytes / four BGR555 banks | `0804831C..48334` dereferences entry 0 and assigns +0/+32/+64/+96; DMA banks 6..9 at `0804C8CC..8FE` | Confirmed for palette set 0 |
| Multipart record `+38` | Base-frame pointer table, 12x8-tile compact streams | `0804C900..926` and `0804C458..47C`; independently validated exact 3072-byte output | Confirmed |
| Multipart record `+3C`; `+2F >> 6` | Two-level part tables: actor flag state -> part -> frame; count is selector top two bits | `0804C92A..99E`, `0804C480..4EC`; state chosen by target flag bit `0800` | Confirmed pointer graph; state 0 exported |
| Multipart upload slots | Each part is 6x8 tiles, at atlas x=12+6*part, y=0 | Native dimensions 6,8; VRAM destination starts base+`180` and increments `C0` bytes; VRAM row stride 1024 | Confirmed |
| Multipart selector `(record[2F] >> 4) & 3` | Mode 0 cycles two pointers; mode 1 cycles four | `0804C400..43A`: XOR 1 versus increment/reset at 4 | Confirmed for implemented modes 0/1 |
| `080406DA..4071E`, `080401C4..40290` | Row-major BG layout consumption, 32-tile destination pitch | Source pitch is declared width; each halfword supplies tile, flips and palette bank; `layout_render` | Confirmed for accepted layouts |
| `08040014..40060` | GBA 0x10 LZ77 / 0x30 RLE dispatch | Inherited strict Python decoder; new 14 direct cases use LZ77, new nine multipart cases use RLE | Confirmed for accepted streams |

All 20 saved native-code windows are byte-identical between Japanese and English
baselines. For each accepted mapping, graphics fields, pointer tables actually
used, palettes, layouts, descriptors and consumed compressed streams also match
at the same source offsets. Translation text fields are deliberately excluded
from asset equality checks. Input SHA-256 values:

- JP: `0d44380a3eed065b6ca0992d80a248ab001b978e925f7687d5dfcf1ae70e5c12`
- English: `8d27aac43d50eab17d7ba8b4183cb7c70dbd74194d11b3f8c011c61d13b5adde`

## Why the 14 direct cases now work

V1 treated compact upload dimensions as image dimensions and required a simple
row-major layout of that same size. In these previously unresolved cases, the
game rearranges the uploaded tiles through its layout/OBJ descriptors:

- Thirteen records upload **80x40** pixels but compose into **40x80** sprites.
- Brikkypress 9A uploads **96x40** but composes into **48x72**; the six unused
  upload tiles are not added to the visible canvas.

Canvas bounds are derived from explicit object coordinates and hardware shape/
size fields, with no trimming by apparent artwork. The tilemap is then read at
those bounds and rendered independently from the same explicitly loaded tile
atlas. Every exported new frame must match the separately rendered OAM image in
alpha and every visible RGB channel. RGB underneath alpha-zero pixels is retained
from palettes and is not part of visible equality. Selected previews for Pothead
and Oops were inspected; no game screenshot or animation playback was compared.

## Remaining blockers and candidate findings

**25 null-reference records:** palette/frame/layout fields are zero. Their IDs
and raw graphics fields are in the inventory. Some may be children of multipart
owners, but proximity, names and compatible sizes do not prove ownership,
independent dimensions or palette selection. No such link is implemented.

**Six composition disagreements:** Brikky 1D, Mirrolick 2E, Conda Kid 43/45/47,
and Brikky 49. The pointer graphs, canvas nibbles, part counts, frame mode and
stream headers are reproducible **candidate evidence** in the inventory. They
are not complete verified enemy mappings: independently rendered tilemap and
OAM representations disagree for the selected state. The exporter fails closed;
it does not choose whichever looks plausible or change part/ palette states to
force a match. Mirrolick also has an initializer-specific secondary-layout
reference at `08048390..4839A` (bus `085EA4F4`); its role is not folded into a
guessed composite.

**Chekkit 8C:** record base table at file `00634D8C`; frame-2 pointer field
`00634D94` selects file `005D2BA8`, header `30 00 0C 00` (advertised 3072 bytes).
A final RLE token exceeds that size under the strict decoder. Frames 0/1/3 and
part streams decode, but no frame is exported for this record. Toolkit RLE
clipping behavior alone does not establish the correct BIOS/upload behavior for
this stream; clipping or padding has not been enabled to bypass the gate.

## Reproduction and verification

From the workspace root, using a fresh output directory:

```powershell
python -B tools/extract/enemy_sprites_v2/extract_enemy_sprites.py --output NEW_V2_DIRECTORY --previews
python -B tools/extract/enemy_sprites_v2/test_enemy_sprites.py
python -B tools/extract/enemy_sprites_v1/test_enemy_sprites.py
```

The extractor refuses an existing output directory and creates every file
exclusively. Eight v2 tests and seven unchanged v1 tests pass. Checks cover all
508 v1 PNGs byte for byte, all 254 old metadata rows without field changes, the
eight earlier Detector/Rattlin' Dragon images, all 23 new composition proofs,
source-span equality, rejection paths, exact canvas examples, PNG CRC/dimensions/
scanlines/alpha, and every enlarged preview's nearest-neighbor pixels.
`verification_complete.json` captures both test outputs and the final preservation
audit. `verification_final.json` is the earlier passing audit, retained unchanged.
`descriptor_selection_proof.json` supplements the asset evidence: each accepted
record's default OBJ descriptor index is independently selected by its native
six-byte animation script. Multipart cycle entries are checked individually;
ordinary actors use the default script. All are single-entry loops selecting
descriptor zero. Script/table ranges and JP/English equality are recorded, and
the extractor rejects unsupported selection scripts.

## Pre-write baseline and preservation

Before the first filesystem write in this session, a complete scoped inventory
hashed **3,939 existing files with zero read errors**. It includes all existing
ROMs, saves, savestates, prior outputs/PNGs/reports, translation assets and tools.
Scope: every workspace file, without an extension filter, excluding `.git`, the
installed `Ghidra/` tree, Python caches, and generated `api-classes`/`compile-libs`
directories. The first successful baseline was held in memory; a second complete
zero-error pass was persisted as `protected_before.zlib.b64` and
`protected_before.json`, still before any extraction/code/report writes.

The final audit rehashes every protected path, detects missing files, and checks
that newly created files are confined to `tools/extract/enemy_sprites_v2/` and
`reverse_engineering/exports/enemy_sprites_v2/`. No original protected file is
opened for writing. Local asset directories contain ignore files; no extracted
copyrighted assets are committed or published. These are static extraction
results; no runtime validation is claimed.
